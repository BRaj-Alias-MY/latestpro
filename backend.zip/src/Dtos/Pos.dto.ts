export interface PosDto {
    item:string;
    item_name:string;
    item_desc:string;
    po_no:number;
    batch_no:number;
    lot_no:number;
    barcode_number:number;
}


 