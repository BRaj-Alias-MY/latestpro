import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { POSEntity } from  '../Models/PosEntity.entity';
import { PosController} from  '../Controllers/PosController.component';
import {PosService} from '../Services/PosRepository.service';
import {PostEntity} from '../Models/Posts.entity';


@Module({
  imports: [TypeOrmModule.forFeature([POSEntity,PostEntity])],
  providers: [PosService],
  controllers: [PosController],
})

export class InfraStructureModule { }