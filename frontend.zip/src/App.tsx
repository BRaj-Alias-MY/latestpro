import * as React from 'react';
import './App.css';
import Main from './Main';
import {Provider} from 'react-redux';
import store from './store';

class App extends React.Component {
  public render() {
    return (
      <Provider store={store}>
      <div> 
        <Main/>
     </div>
     </Provider>
    );
  }
}

export default App;
