import * as React from 'react'
import { connect } from 'react-redux';
import { fetchPosts } from '../../actions/postActions'
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';


class Grn extends React.Component<any, any> {

  constructor(props: any) {
    super(props)

    this.state = { visible: false };
    this.actionTemplate = this.actionTemplate.bind(this);
    this.onSub = this.onSub.bind(this);
  }

  public onSub(selectedColumn: any) {
    const id = selectedColumn.rowData.Id;
    this.props.history.push(`/grndetails/${id}`);
  }


  public actionTemplate(rowData: any, column: any) {

    return (
      < div >
        <Button onClick={(e) => this.onSub(column)} type="button" icon="pi pi-search" className="p-button-success" />
      </div >
    );
  }


  public componentWillMount() {
    this.props.fetchPosts();
  }
  public render() {

    const paginatorLeft = <Button icon="pi pi-refresh" />;
    const paginatorRight = <Button icon="pi pi-cloud-upload" />;



    return (
      <div>
        <h1>POs</h1>
        <DataTable value={this.props.posts} paginator={true} paginatorLeft={paginatorLeft} paginatorRight={paginatorRight} rows={10} rowsPerPageOptions={[5, 10, 20]}>
          <Column style={{ textAlign: 'center', width: '80px' }} field="Id" header="S.No" />
          <Column field="po_no" header="PO Number" />
          <Column field="quantity" header="Quantity" />
          <Column header="Action" body={this.actionTemplate} style={{ textAlign: 'center', width: '6em' }} />
        </DataTable>



      </div>
    )
  }
}

const mapStateToProps = (state: any) => ({

  posts: state.posts.items,
});

export default connect(mapStateToProps, { fetchPosts })(Grn);
