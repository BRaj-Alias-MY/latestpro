import * as React from 'react'
import '../../assets/css/style.css'

class GrnDetails extends React.Component<any, any> {
  private nameRef: React.RefObject<any>;
  private courseRef: React.RefObject<any>;
  private classRef: React.RefObject<any>;
  private firstRef: React.RefObject<any>;
  constructor(props: any) {
    super(props)
    this.nameRef = React.createRef();
    this.courseRef = React.createRef();
    this.firstRef = React.createRef();
    this.classRef = React.createRef();

    this.state = {
      name: this.props.match.params.id,
      podetails: [{ name: '', class: '', course: '' }],
    };

  }


  public handleNameChange = (evt: any) => {
    this.setState({ name: this.firstRef.current.value });
  };

  public handlepoNameChange = (idx: any) => (evt: any) => {
    const newpodetails = this.state.podetails.map(
      (po: any, sidx: any) => {
        if (idx !== sidx) { return po };
        return {
          ...po,
          name: this.nameRef.current.value,
          class: this.classRef.current.value,
          course: this.courseRef.current.value,
        };
      }
    );

    this.setState({ podetails: newpodetails });
  };

  public handleSubmit = (evt: any) => {
    evt.preventDefault();
    // const { name, podetails } = this.state;
    console.log(this.state);
  };


  public handleAddpo = () => {
    this.setState({
      podetails: this.state.podetails.concat([
        { name: '', class: '', course: '' },
      ]),
    });
  };

  public handleRemovepo = (idx: any) => () => {
    this.setState({
      podetails: this.state.podetails.filter((s: any, sidx: any) => idx !== sidx),
    });
  };


  public render() {
    /*
        const id = this.props.match.params.id;
        console.log(this.props)
        */
    const id = this.props.match.params.id;
    return (
      <form onSubmit={this.handleSubmit}>
        <input
          type="hidden"
          placeholder="Company name, e.g. Magic Everywhere LLC"
          value={id}
          onChange={this.handleNameChange}
          ref={this.firstRef}
          className="form-control"
        />

        <h2>PO Order Details : {id}</h2>

        {this.state.podetails.map((po: any, idx: any) => (

          <div key={idx} className="po col-md-12">
            <table className="table table-hovered">
              <tbody>
                <tr>
                  <td>
                    <input
                      type="text"
                      placeholder={`po #${idx + 1} name`}
                      value={po.name}
                      onChange={this.handlepoNameChange(idx)}
                      ref={this.nameRef}
                      className="form-control input"
                    />
                  </td>
                  <td>

                    <input
                      type="text"
                      placeholder={`po #${idx + 1} name`}
                      value={po.class}
                      onChange={this.handlepoNameChange(idx)}
                      ref={this.classRef}
                      className="form-control input"
                    />
                  </td>
                  <td>

                    <input
                      type="text"
                      placeholder={`po #${idx + 1} name`}
                      value={po.course}
                      onChange={this.handlepoNameChange(idx)}
                      ref={this.courseRef}
                      className="form-control input"
                    />
                  </td>
                  <td>
                    <button
                      type="button"
                      onClick={this.handleRemovepo(idx)}
                      className="btn btn-danger"
                    >
                      -
            </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        ))}
        <div className="text-center">
          <button
            type="button"
            onClick={this.handleAddpo}
            className="btn btn-success"
          >
            Add po
        </button>
          <button className="btn btn-primary">Submit Data</button>
        </div>
      </form>
    )
  }
}

export default GrnDetails
