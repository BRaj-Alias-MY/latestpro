import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './assets/css/style.css';
import Grn from './components/pages/Grn';
import { Route, NavLink, BrowserRouter, Switch } from 'react-router-dom';
import GrnDetails from './components/pages/GrnDetails';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

export default class Main extends React.Component {
  public render() {
    return (
      <BrowserRouter>

        <React.Fragment>

          <nav className="navbar navbar-expand-lg navbar-light bg-dark">
            <NavLink className="navbar-brand logo" to="/">GRN</NavLink>
            <button
              className="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarText"
              aria-controls="navbarText"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon" />
            </button>
            <div className="collapse navbar-collapse" id="navbarText">
              <ul className="navbar-nav mr-auto">
                <li className="nav-item">
                  <NavLink className="nav-link" to="/">POs</NavLink>
                </li>



                <li className="nav-item">
                  <NavLink className="nav-link" to="/inspection">
                    Inspection
                  </NavLink>
                </li>

              </ul>

            </div>
          </nav>

          <div className="container-fluid">
            <div className="row">
              <div className="col-md-12">
                <div className="content">
                  <Switch>
                    <Route exact path="/" component={Grn} />
                    <Route path="/grndetails/:id" component={GrnDetails} />

                    <Route component={Grn} />
                  </Switch>
                </div>
              </div>


            </div>

          </div>

        </React.Fragment>

      </BrowserRouter>
    )
  }
}
